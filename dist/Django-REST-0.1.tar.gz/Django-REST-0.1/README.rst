=====
DJANGO-REST-API
=====

Django-REST-API is an app which lets you make get request for getting user information specified by userid or username.


Quick start
-----------

1. Add "api_response" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        api_response,
    ]

2. Include the polls URLconf in your project urls.py like this::
    import api_response
    path('api.yourDomain/', include('api_response.urls')),
    
	YOU CAN CHANGE THE URL PATTERN HERE ACCORDING TO YOUR PREFERANCE
	BUT DON'T FORGET TO ADD "/users" WHILE MAKING API REQUESTS AT THE END.
	FOR EX:
		http://127.0.0.1:8000/YOUR_PATTERN/users/ "id OR username"


3. Start the development server and visit http://127.0.0.1:8000/api.yourDomain/
   to create a poll (you'll need the Admin app enabled).

5. To request user info visit::
    
	http://127.0.0.1:8000/api.yourDomain/users/id/
			OR
	http://127.0.0.1:8000/api.yourDomain/users/username_here/

    You can request userinfo either by username or id.

6. If you have a user profile app which extends django default user configurations, then to merge profile add    following to your settings.py::
	
	INCLUDE_PROFILE = True
	PROFILE_MODEL = # your_profile_model here // can be found at your profile.models
			# you can set profile model either by importing actual class like:
				from profile.models import Profile

				INCLUDE_PROFILE = True
				PROFILE_MODEL = Profile
		
						OR

			# just specify the name of class which has one-to-one relation with user like:

				INCLUDE_PROFILE = True
				PROFILE_MODEL = 'profile'