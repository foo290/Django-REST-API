from django.apps import AppConfig


class ApiResponseConfig(AppConfig):
    name = 'api_response'
